-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2024 at 03:12 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_student` (IN `p_stdID` INT, IN `p_fname` VARCHAR(255), IN `p_lname` VARCHAR(255), IN `p_DOB` VARCHAR(255), IN `p_gender` VARCHAR(10), IN `p_number` VARCHAR(255), IN `p_email` VARCHAR(255), IN `p_address` VARCHAR(255), IN `p_departmentID` INT, IN `p_sectionID` INT, IN `p_password` VARCHAR(255), IN `p_nic` BIGINT)   BEGIN
    INSERT INTO Student (
        stdID, fname, lname, DOB, gender, PhoneNo, email, address, departmentID, sectionID, password, nic
    ) VALUES (
        p_stdID, p_fname, p_lname, p_DOB, p_gender, p_number, p_email, p_address, p_departmentID, p_sectionID, p_password, p_nic
    );
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `enrollmentID` int(11) DEFAULT NULL,
  `status` varchar(5) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL
) ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`enrollmentID`, `status`, `date`) VALUES
(301, 'P', '5-12-23'),
(302, 'P', '4-12-23'),
(302, 'A', '6-12-2023'),
(301, 'p', '4-5-2023'),
(304, 'p', '4-5-2023'),
(302, 'P', '7-9-2023'),
(301, 'P', '6-12-23'),
(304, 'A', '6-12-23'),
(305, 'P', '6-12-23'),
(302, 'A', '7-12-2023'),
(302, 'P', '5-5-12'),
(303, 'A', '4-3-23'),
(306, 'A', '4-3-23'),
(302, 'A', '4-6-2023'),
(302, 'P', '4-12-2023'),
(302, 'p', '12-11-2024');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `courseID` int(11) NOT NULL,
  `courseName` varchar(255) DEFAULT NULL,
  `creditHour` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseID`, `courseName`, `creditHour`) VALUES
(101, 'Database Management', 3),
(102, 'Software Quality Testing', 4),
(103, 'Algorithms', 3);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `departmentID` int(11) NOT NULL,
  `departName` varchar(255) DEFAULT NULL,
  `HOD` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`departmentID`, `departName`, `HOD`) VALUES
(1, 'Computer Science', 101),
(2, 'Software Engineering', 102),
(3, 'Cyber Security', 103);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE `enrollment` (
  `enrollmentID` int(11) NOT NULL,
  `stdID` int(11) DEFAULT NULL,
  `courseID` int(11) DEFAULT NULL,
  `sectionID` int(11) DEFAULT NULL,
  `teacherID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`enrollmentID`, `stdID`, `courseID`, `sectionID`, `teacherID`) VALUES
(301, 201, 101, 3, 102),
(302, 202, 101, 3, 101),
(303, 203, 101, 3, 103),
(304, 205, 102, 3, 102),
(305, 202, 102, 3, 102),
(306, 201, 102, 3, 103),
(309, 209, 102, 1, 101);

--
-- Triggers `enrollment`
--
DELIMITER $$
CREATE TRIGGER `update_enrollment_count` AFTER INSERT ON `enrollment` FOR EACH ROW BEGIN
    DECLARE current_enrollment INT;

    -- Get the current enrollment count for the section
    SELECT COUNT(*) INTO current_enrollment
    FROM Enrollment
    WHERE sectionID = NEW.sectionID;

    -- Update the enrollment count in the Section table
    UPDATE Section
    SET enrollmentCount = current_enrollment
    WHERE sectionID = NEW.sectionID;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `grading`
--

CREATE TABLE `grading` (
  `enrollmentID` int(11) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grading`
--

INSERT INTO `grading` (`enrollmentID`, `marks`) VALUES
(302, 10),
(301, 24),
(304, 11),
(302, 30);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `enrollmentID` int(11) DEFAULT NULL,
  `topic` varchar(20) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `obtain` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`enrollmentID`, `topic`, `total`, `obtain`) VALUES
(301, 'Mid 1', 15, 12),
(302, 'Mid 1', 15, 10),
(301, 'mid 2', 15, 12),
(304, 'mid 2', 15, 11),
(301, 'Quiz', 3, 2),
(304, 'Quiz', 3, 1),
(305, 'Quiz', 3, 2),
(302, 'Quiz 2', 3, 0),
(302, 'Mid', 30, 20);

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `sectionID` int(11) NOT NULL,
  `sectionName` varchar(255) DEFAULT NULL,
  `departmentID` int(11) DEFAULT NULL,
  `enrollmentCount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`sectionID`, `sectionName`, `departmentID`, `enrollmentCount`) VALUES
(1, 'CS 1A', 1, 1),
(2, 'CS 1B', 1, 0),
(3, 'SE 1A', 2, 6),
(4, 'CYBER 1A', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stdID` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `DOB` varchar(20) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `PhoneNo` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `departmentID` int(11) DEFAULT NULL,
  `sectionID` int(11) DEFAULT NULL,
  `nic` bigint(13) NOT NULL,
  `password` varchar(255) DEFAULT NULL
) ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stdID`, `fname`, `lname`, `DOB`, `gender`, `PhoneNo`, `email`, `address`, `departmentID`, `sectionID`, `nic`, `password`) VALUES
(201, 'Muhammad', 'usman', '2004-07-04', 'M', '111-222-3333', 'XYZ@example.com', '123 Main St', 2, 3, 1234567891236, '123'),
(202, 'irteza', 'UlHaq', '2004-07-04', 'M', '111-222-3333', 'XYZ@example.com', '123 Main St', 2, 3, 1234567891243, '123'),
(203, 'Ahmed', 'saffan', '2004-07-04', 'M', '111-222-3333', 'XYZ@example.com', '123 Main St', 2, 3, 1234567891253, '123'),
(204, 'ammar', 'binusamn', '2003-04-05', 'M', '12345', 'zyx@hyf', 'asd', 2, 3, 1234567891234, '123'),
(205, 'asd', 'ads', 'asd', 'M', '1312', 'afdsf', 'afsf', 2, 3, 1234567891235, '123'),
(206, 'anser', 'tayyab', 'xyz', 'm', '123', 'xyz', 'xyz', 1, 1, 1239871231231, '123'),
(207, 'osman', 'xyz', 'xyz', 'm', '123', 'xyz', 'xyz', 1, 1, 9871231231233, '123'),
(208, 'xyz', 'xyz', 'xyz', 'm', '123xyz', 'xyz', 'xyz', 1, 1, 9876543219876, '123'),
(209, 'xyz', 'xyz', 'xyz', 'f', 'xyz', 'xyz', 'xyz', 1, 1, 9876543210123, '123');

-- --------------------------------------------------------

--
-- Table structure for table `taught`
--

CREATE TABLE `taught` (
  `teacherID` int(11) NOT NULL,
  `courseID` int(11) NOT NULL,
  `sectionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `taught`
--

INSERT INTO `taught` (`teacherID`, `courseID`, `sectionID`) VALUES
(101, 102, 3),
(102, 101, 3),
(103, 101, 3);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacherID` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `PhoneNo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacherID`, `fname`, `lname`, `email`, `PhoneNo`) VALUES
(101, 'Miss', 'Rubab', 'miss.rubab@example.com', '123-456-7890'),
(102, 'Miss', 'Abeer', 'miss.abeer@example.com', '987-654-3210'),
(103, 'Ali', 'Fathmi', 'ali.fathmi@example.com', '555-123-4567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`departmentID`),
  ADD KEY `HOD` (`HOD`);

--
-- Indexes for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`enrollmentID`),
  ADD KEY `stdID` (`stdID`),
  ADD KEY `courseID` (`courseID`),
  ADD KEY `sectionID` (`sectionID`),
  ADD KEY `teacherID` (`teacherID`);

--
-- Indexes for table `grading`
--
ALTER TABLE `grading`
  ADD KEY `enrollmentID` (`enrollmentID`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD KEY `enrollmentID` (`enrollmentID`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`sectionID`),
  ADD KEY `departmentID` (`departmentID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stdID`),
  ADD KEY `departmentID` (`departmentID`),
  ADD KEY `sectionID` (`sectionID`);

--
-- Indexes for table `taught`
--
ALTER TABLE `taught`
  ADD PRIMARY KEY (`teacherID`,`courseID`,`sectionID`),
  ADD KEY `courseID` (`courseID`),
  ADD KEY `sectionID` (`sectionID`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacherID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`HOD`) REFERENCES `teacher` (`teacherID`);

--
-- Constraints for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`stdID`) REFERENCES `student` (`stdID`),
  ADD CONSTRAINT `enrollment_ibfk_2` FOREIGN KEY (`courseID`) REFERENCES `course` (`courseID`),
  ADD CONSTRAINT `enrollment_ibfk_3` FOREIGN KEY (`sectionID`) REFERENCES `section` (`sectionID`),
  ADD CONSTRAINT `enrollment_ibfk_4` FOREIGN KEY (`teacherID`) REFERENCES `teacher` (`teacherID`);

--
-- Constraints for table `grading`
--
ALTER TABLE `grading`
  ADD CONSTRAINT `grading_ibfk_1` FOREIGN KEY (`enrollmentID`) REFERENCES `enrollment` (`enrollmentID`);

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`enrollmentID`) REFERENCES `enrollment` (`enrollmentID`);

--
-- Constraints for table `section`
--
ALTER TABLE `section`
  ADD CONSTRAINT `section_ibfk_1` FOREIGN KEY (`departmentID`) REFERENCES `department` (`departmentID`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`departmentID`) REFERENCES `department` (`departmentID`),
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`sectionID`) REFERENCES `section` (`sectionID`);

--
-- Constraints for table `taught`
--
ALTER TABLE `taught`
  ADD CONSTRAINT `taught_ibfk_1` FOREIGN KEY (`teacherID`) REFERENCES `teacher` (`teacherID`),
  ADD CONSTRAINT `taught_ibfk_2` FOREIGN KEY (`courseID`) REFERENCES `course` (`courseID`),
  ADD CONSTRAINT `taught_ibfk_3` FOREIGN KEY (`sectionID`) REFERENCES `section` (`sectionID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
